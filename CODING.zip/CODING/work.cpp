#include <iostream>
using namespace std;

int main() {
    double num1 = 15.5;
    int num2;
    cout<<"Implicit Type Casting" << endl;
    num2 = num1;
    cout<<"Value of num2: "<< num2 <<endl;
    cout<<"\n\nExplicit type casting" << endl;
    cout<<"before explicit conversion: \n";
    cout<<"num1 before explicit conversion"<<num1<<endl;
    num2 = (int)num1;
    num2 = static_cast<int>(num1);
    num2 = static_cast<int>(num1);
    num2 = static_cast<int>(num1);
    num2 = static_cast<int>(num1);
    cout<<"num1 after explicit conversion: "<< num1 << endl;
    cout<<"num2 after explicit conversion: "<< num1 << endl;
    return 0;
}