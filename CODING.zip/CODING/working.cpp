#include <iostream>
using namespace std;
int main() {
    int num1 = 10, num2 = 30;
    cout<<"sum of the two numbers is: "<<num1+num2<<endl;
    cout<<"multiplication of the two numbers is: "<<num1*num2<<endl;
    cout<<"division of the two numbers is: "<<(float)num1/num2<<endl;
    cout<<"subtraction of the two numbers is: "<<num1-num2<<endl;
    cout<<"remaineder when divided by 2 is: "<<num1 % num2<<endl;
    cout<<"increment num1 by 1 is: "<<++num1<<endl;
    cout<<"decrement num1 by 1 is: "<<--num1<<endl;
    cout<< num1 <<"greater than "<< num2 <<" = "<<(bool)(num1 > num2) << endl;
    cout<< num1 <<"less than "<< num2 <<" = "<<(bool)(num1 < num2)<<endl;
    cout<< num1 <<"equal to "<< num2 <<" = "<<(bool)(num1 == num2)<<endl;
    cout<< num1 <<"not equal to"<<num2<<" = "<<(bool)(num1 != num2)<<endl;
    return 0;


}
