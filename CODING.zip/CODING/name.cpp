#include <iostream>
using namespace std;
int main() {
    string first_name, last_name, full_name;
    cout<<"enter firstname\n";
    getline (cin, first_name);
    cout<<"enter second_name";
    getline(cin, last_name);
    cout<<"enter full_name";
    return 0;
}