#include <iostream>
using namespace std;
int main() { 
    int sum, subtract, multiply, divide;
    int length;
    length = 8;
    int width;
    width = 5;
    sum = length + width;
    subtract = length - width;
    multiply = length * width;
    divide = length / width;
    cout<<"Addition is : "<<sum<<endl;
    cout<<"Subtraction is : "<<subtract<<endl;
    cout<<"Multiplication is : "<<multiply<<endl;
    cout<<"Division is : "<<divide<<endl;
    return 0;
}
   